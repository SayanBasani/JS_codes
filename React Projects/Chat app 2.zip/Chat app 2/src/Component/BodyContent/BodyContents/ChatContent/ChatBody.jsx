import { useContext } from "react"
import ChatNav from "./ChatNav/ChatNav"
import { TheContext } from "../../../Storages/Store&Functions"
import FriendsChats from "./FriendsChats/FriendsChats"

export default function ChatBody() {
  const { Contacts } = useContext(TheContext)

  return (
    <>
      <div className="flex h-screen">
      {/* <div className="grid snap-none d">
      </div> */}
        <ChatNav Contacts={Contacts}></ChatNav>
      <div className="">
        <FriendsChats></FriendsChats>
      </div>
      </div>
      
    </>
  )
}