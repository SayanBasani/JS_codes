import { createContext, useState } from "react"


export const TheContext = createContext({});

function HandleContet({ children, value }) {
  const NavOptions = [
    {
      title: "Chat",
      iconBootstrap: "bi-chat-left-text"
    },
    {
      title: "Create Post",
      iconBootstrap: "bi-plus-circle"
    },
    {
      title: "Videos",
      iconBootstrap: "bi-play-btn-fill"
    },
    {
      title: "Reels",
      iconBootstrap: " bi-file-play-fill"
    }
  ]
  const Contact = [
    {
      img : "bi-person-square",
      Friend_Name : "Adersh Mondal"
    },
    {
      img : "bi-person-square",
      Friend_Name : "Aju(Subham)"
    },
    {
      img : "bi-person-square",
      Friend_Name : "Adersh Mondal"
    },
    {
      img : "bi-person-square",
      Friend_Name : "Sayan Basani"
    },
    {
      img : "bi-person-square",
      Friend_Name : "Soumyadip Gupta"
    },
    {
      img : "bi-person-square",
      Friend_Name : "Aju(Subham)"
    },
    {
      img : "bi-person-square",
      Friend_Name : "Adersh Mondal"
    },
    {
      img : "bi-person-square",
      Friend_Name : "Sayan Basani"
    },
    {
      img : "bi-person-square",
      Friend_Name : "Soumyadip Gupta"
    },
    {
      img : "bi-person-square",
      Friend_Name : "Aju(Subham)"
    },
    {
      img : "bi-person-square",
      Friend_Name : "Adersh Mondal"
    },
    {
      img : "bi-person-square",
      Friend_Name : "Sayan Basani"
    },
    {
      img : "bi-person-square",
      Friend_Name : "Soumyadip Gupta"
    },
    

  ]
  const [Navoption, setNavoption] = useState(NavOptions);
  const [Contacts , setContacts] = useState(Contact);
  const [selectNav, setselectNav] = useState("");
  console.log(`it is ccc ${selectNav}`);

  
  return (
    <TheContext.Provider value={{
      ...value,Navoption,setNavoption,Contacts,setContacts
      ,selectNav,setselectNav,
      }}>
      {children}
    </TheContext.Provider>
  )
}
export default HandleContet;