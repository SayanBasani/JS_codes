import 'bootstrap-icons/font/bootstrap-icons.css';
import { useContext, useState } from 'react';
import { TheContext } from '../Storages/Store&Functions';

export default function Nav() {
  const { Navoption ,setselectNav } = useContext(TheContext);
  const [isExpanded, setIsExpanded] = useState(false);
  const toggleSidebar = () => {
    setIsExpanded(!isExpanded);
  };

  return (
    <div className={`bg-gray-800 text-white h-screen transition-all duration-300 ease-in-out ${isExpanded ? 'w-48' : 'w-12'}`}>
      <div className="p-3 flex sticky top-0 bg-gray-800">
        <button onClick={toggleSidebar}>
          <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 12h12M6 6h12M6 18h12" />
          </svg>
        </button>
      </div>

      <ul className="mt-10 space-y-4 text-center flex flex-col pl-3 justify-center">
        {Navoption.map((items, index) => (
          <li key={index} className={`flex flex-row gap-3 cursor-pointer`} 
          onClick={()=>(
            setselectNav(items.title)
          )}
            >
            <i className={`bi ${items.iconBootstrap}`}></i>
            {isExpanded && <span className="text-xs font-bold flex items-center">{items.title}</span>}
          </li>
        ))}
      </ul>
    </div>
  );
}


