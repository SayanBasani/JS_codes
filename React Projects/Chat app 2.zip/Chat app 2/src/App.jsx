import { useContext} from 'react';
import './App.css';
import Nav from './Component/SideNav/Nav';
import HandleContet, { TheContext } from './Component/Storages/Store&Functions';
import HeaderMain from './Component/BodyContent/Header/HeaderMain';
import ChatBody from './Component/BodyContent/BodyContents/ChatContent/ChatBody';

function App() {
  const {selectNav} = useContext(TheContext)
  console.log(`it is ${selectNav}`);
  
  return (
    <>
      <HandleContet>
        <div className="flex h-screen">
          {/* Sidebar */}
          <Nav className="h-full"></Nav>

          {/* Main Content */}
          <div className="flex flex-col w-full h-full bg-slate-300">
            {/* Sticky Header */}
            <div className="h-auto sticky top-0">
              <HeaderMain />
            </div>

            {/* Chat Body Scrollable */}
            <div className="flex-grow overflow-y-auto">
              <ChatBody />
            </div>
          </div>
        </div>
      </HandleContet>
    </>
  );
}

export default App;
