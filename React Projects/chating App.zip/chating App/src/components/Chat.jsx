import style from "./Chat.module.css"
function Chat(){
  return <div className={`w-100 ${style.chatBody}`}>
    One Person all chats ....
  </div>
}
export default Chat